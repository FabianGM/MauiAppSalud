﻿namespace MauiAppSalud.Models.Constantes
{
    public class Constantes
    {
        public const string VALOR_VACIO = "";
        public const int VALOR_CERO = 0;
    }
}