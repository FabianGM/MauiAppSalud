﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using MauiAppSalud.Controllers;
using MauiAppSalud.Models;
using MauiAppSalud.Models.Constantes;
using MauiAppSalud.Services;

namespace MauiAppSalud.ViewModels
{
    /// <summary>
    /// ViewModel para gestionar los detalles del profesional y sus servicios disponibles.
    /// </summary>
    public class DetallesProfesionalVmo : BaseVmo
    {
        /// <summary>
        /// Tipo de ayuda que ofrece el profesional
        /// </summary>
        public TipoAyudaMod TipoAyuda { get; set; }

        /// <summary>
        /// Colección observable de servicios disponibles.
        /// </summary>
        public ObservableCollection<TipoAyudaMod> ServiciosDisponibles { get; set; }

        /// <summary>
        /// Comando para continuar con el servicio seleccionado.
        /// </summary>
        public ICommand ComandoContinuar { get; }

        /// <summary>
        /// Controlador para manejar los tipos de ayuda del sistema
        /// </summary>
        public TipoAyudaController cTipoAyuda { get; set; }

        /// <summary>
        /// Constructor sin parametros que inicializa los datos y los comandos.
        /// </summary>
        public DetallesProfesionalVmo()
        {
            // Inicializa el modelo y controlador
            TipoAyuda = new TipoAyudaMod();
            cTipoAyuda = new TipoAyudaController(new SrvTipoAyuda());

            // Obtiene el idProfesional de las preferencias (almacenamiento local)
            int idProfesional = Preferences.Get("idProfesional", Constantes.VALOR_CERO);

            // Llama al método para cargar los servicios disponibles con el idProfesional
            ServiciosDisponibles = cTipoAyuda.ObtenerTipoAyuda(idProfesional);

            // Define el comando para continuar con el servicio
            ComandoContinuar = new Command<TipoAyudaMod>(ContinuarConServicio);
        }

        /// <summary>
        /// Método que se ejecuta cuando el usuario selecciona un servicio y presiona el botón "Continuar".
        /// </summary>
        /// <param name="servicio">El servicio seleccionado.</param>
        private void ContinuarConServicio(TipoAyudaMod servicio)
        {
            // Lógica cuando se selecciona un servicio, aquí podrías navegar a otra página
            Console.WriteLine($"Servicio seleccionado: {servicio.NombreServicio}");
            // Lógica adicional (navegación, validación, etc.) puede implementarse aquí.
        }
    }
}
